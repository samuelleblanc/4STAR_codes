function TorF = isNaN(x);
TorF = isnan(x);
return