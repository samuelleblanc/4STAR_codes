function y=meannonan(x)

y=nanmean(x);

return